<?php 
  session_start();
  require 'dbasecode/connect.php';
  require 'fpdf181/fpdf.php';
  
  $reserID = $_GET['reservationID'];
  $query = mysqli_query($conn, "SELECT * FROM tblreservation WHERE reservationID = '$reserID'");
    while ($row = mysqli_fetch_array($query)){
      $code = $row['reservationCode'];
        $status = $row['status'];
        $bookingDate=$row['bookingDate'];
        $checkin=$row['checkin'];
        $checkout=$row['checkout'];
        $roomid = $row['roomID'];
        $guestid = $row['guestsID'];
    $query1 = mysqli_query($conn, "SELECT * FROM tblroom WHERE roomID = '$roomid'");
    $row1 = mysqli_fetch_array($query1);
        $roomname = $row1['roomType'];
        $roomrate = $row1['roomRate'];
        $roomcapacity = $row1['roomCapacity'];  
    $query2 = mysqli_query($conn, "SELECT * FROM tblguests WHERE guestsID = '$guestid'");
  $row2 = mysqli_fetch_array($query2);
    $fName = $row2['fName'];
    $lName = $row2['lName'];
    $email = $row2['email'];
    $contact = $row2['contactNo'];
    $bDay = $row2['bday'];
    $add = $row2['address'];
    


  $pdf = new FPDF();

  $pdf -> AddPage();
  $pdf -> SetFont("helvetica", "", "14");
  $pdf -> Cell(0, 10, "Reservation Form", 0, 1, "C");
  $pdf -> Line(10, 20, 200, 20);
  $pdf -> Image('assets/images/BBR.png', 90, 20, 30, 20);
  $pdf -> SetFont("helvetica", "B", "12");
  $pdf -> Cell(0, 50, "BELLA BEACH RESORT", 0, 1, "C");
  $pdf -> SetFont("helvetica", "", "12");
  $pdf -> Cell(0, -40, "Ligtasin, Luyahan, Lian, 4216 Batangas", 0, 1, "C");
  $pdf -> Line(10, 55, 200, 55);
  $pdf -> SetFont("helvetica", "B", "12");
  $pdf -> SetTextColor(255, 0, 0);
  $pdf -> Cell(0, 70, "Pay in the bank with this account number 200022142665", 0, 1);
  $pdf -> SetFont("helvetica", "B", "12");
  $pdf -> SetTextColor(0, 0, 0);
  $pdf -> Cell(0, -60, "Reservation Code: {$code}", 0, 1);
  $pdf -> SetFont("helvetica", "", "8");
  $pdf -> SetTextColor(0, 0, 0);
  $pdf -> Cell(0, 70, "(Copy this code to track your reservation. After paying, upload the pic of your deposit slip.)", 0, 1);
  $pdf -> SetFont("helvetica", "B", "12");
  $pdf -> SetTextColor(0, 0, 0);
  $pdf -> Cell(0, -60, "Reservation Status: {$status}", 0, 1);
  $pdf -> SetFont("helvetica", "U", "12");
  $pdf -> SetTextColor(0, 0, 0);
  $pdf -> Cell(0, 80, "Guest Information", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(0, -70, "First Name: {$fName}", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(0, 80, "Last Name: {$lName}", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(0, -70, "Birthday: {$bDay}", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(0, 80, "Address: {$add}", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(0, -70, "Email: {$email}", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(0, 80, "Contact Number: {$contact}", 0, 0);
  $pdf -> SetFont("helvetica", "U", "12");
  $pdf -> Cell(-50, 20, "Reservation Details", 0, 1, "R");
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(101.35);
  $pdf -> Cell(0, -10, "Booking Date: {$bookingDate}", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(101.35);
  $pdf -> Cell(0, 20, "Check-In Date: {$checkin}", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(101.35);
  $pdf -> Cell(0, -10, "Check-Out Date: {$checkout}", 0, 0);
  $pdf -> SetFont("helvetica", "U", "12");
  $pdf -> Cell(-62, 20, "Room Details", 0, 1, "R");
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(100.50);
  $pdf -> Cell(0, -10, "Room Name: {$roomname}", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(100.50);
  $pdf -> Cell(0, 20, "Room Rate: {$roomrate}", 0, 1);
  $pdf -> SetFont("helvetica", "B", "10");
  $pdf -> Cell(100.50);
  $pdf -> Cell(0, -10, "Room Capacity: {$roomcapacity}", 0, 1);
  $pdf -> Line(10, 140, 200, 140);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, 35, "* No private CR for Seaview Room and Native Rooms.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, -25, "* Inclusive all amenities.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, 35, "* Bungalow House - (gas stove & refrigerator provided). No utensils available.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, -25, "* Food exclusives on room rates.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, 35, "* Spacious vehicle parking.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, -25, "* Bar & Restaurant available for food & drinks.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, 35, "* Griller available at the beach area (bring your own charcoal).", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, -25, "* All rooms are fronting the beach and pool except bungalow house.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, 35, "* Please bring proper swimming attire.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, -25, "* (100%) full payment required to confirm your reservation.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, 35, "* Check-in time: 2:00 pm / Check-out time: 12:00 pm.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, -25, "* For bank deposit, the only preferred bank is eastwest bank.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, 35, "* Rates are subject to change without prior notice.", 0, 1);
  $pdf -> SetFont("helvetica", "", "10");
  $pdf -> Cell(0, -25, "* No refund of payment.", 0, 1);


  require 'EMAIL/PHPMailer-master/PHPMailerAutoload.php';
  $mail = new PHPMailer;
  $mail->isSMTP();
  $mail->Host = ' mx1.hostinger.ph';
  $mail->Port = 587;
  $mail->SMTPSecure = 'tls';
  $mail->SMTPAuth = true;
  $mail->Username = "bellabeach@bellabeachresort.xyz";
  $mail->Password = "moraga";
  $mail->setFrom('bellabeach@bellabeachresort.xyz', 'Bella Beach Resort');
  $mail->addReplyTo('bellabeach@bellabeachresort.xyz', 'Bella Beach Resort');
  $mail->addAddress($email);
  $mail->addCC($email);
  $mail->addBCC($email);
  $mail->Subject = 'Reservation Form';
  $mail->Body = 'Good day! This is the attachment of your Reservation Form';
  
  $mail->isHTML(true);  
  
  $mail->addStringAttachment($pdf->Output("S",'reservationform.pdf'), 'reservationform.pdf', $encoding = 'base64', $type = 'application/pdf');
  
  
  if(!$mail->send()) {
    echo "mailer Error: ". $mail->ErrorInfo;
  } else {
   	header("Location: reservation5.php?reservationID=$reserID");
  }
}
?>