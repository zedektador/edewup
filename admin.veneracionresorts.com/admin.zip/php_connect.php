<?php
$conn=mysqli_connect("localhost","elrenzoh","123456e","elrenzoh_db");
?>