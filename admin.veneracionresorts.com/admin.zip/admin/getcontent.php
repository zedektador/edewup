<?php 
$html=file_get_contents("http://facebook.com");

echo $html;