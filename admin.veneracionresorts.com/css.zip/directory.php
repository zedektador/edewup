<?php

include("weblock.php");
?><!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<?php
include("head.php");
?>
<body>
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
             <?php
				include("header.php");
			?>
		
<!--agileinfo-grap-->
<div class="agileinfo-grap">
    <?php
    include("con_directory.php");
    ?>
</div>
	<!--//agileinfo-grap-->
<!--photoday-section-->	
			
                        
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block" style="clear:both; height:5px">

</div>
<!--inner block end here-->
<!--copy rights start here-->
<div class="copyrights">
	 <p>© 2018 El Renzo Hotel | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>	
<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
			<?php
			include("sidebar.php");
			?>
							  <div class="clearfix"></div>		
							</div>
			<?php
			include("js.php");
			?>
</body>
</html>

<script>
Date.prototype.addDays = function(days) {
  var dat = new Date(this.valueOf());
  dat.setDate(dat.getDate() + days);
  return dat;
}

$(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + (day);
	$('#txtDate').attr('min', maxDate);
	$('#txtDate').val(maxDate);
	
	var inDate = $("#txtDate").val();
	var inDate_ = new Date(inDate);
	var inDatex = inDate_.addDays(1);
    var month_ = inDatex.getMonth() + 1;
    var day_ = inDatex.getDate();
    var year_ = inDatex.getFullYear();
    if(month_ < 10)
        month_ = '0' + month_.toString();
    if(day_ < 10)
        day_ = '0' + day_.toString();
	var tomorrow = year_ + '-' + month_ + '-' + (day_);
	
	$('#txtDateOut').attr('min', tomorrow);
	$('#txtDateOut').val(tomorrow);
});

function updDate(){
	var inDate = $("#txtDate").val();
	var inDate_ = new Date(inDate);
	var inDatex = inDate_.addDays(1);
    var month_ = inDatex.getMonth() + 1;
    var day_ = inDatex.getDate();
    var year_ = inDatex.getFullYear();
    if(month_ < 10)
        month_ = '0' + month_.toString();
    if(day_ < 10)
        day_ = '0' + day_.toString();
	var tomorrow = year_ + '-' + month_ + '-' + (day_);
	
	$('#txtDateOut').attr('min', tomorrow);
	$('#txtDateOut').val(tomorrow);
}
</script>

</script>