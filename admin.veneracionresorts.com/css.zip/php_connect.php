<?php
$conn=mysqli_connect("172.93.102.98","elrenzoh","ktqz4flggfz11","elrenzoh_db");
?>