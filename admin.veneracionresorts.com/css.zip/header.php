<!--header start here-->
				<div class="header-main">
					<div class="logo-w3-agile" style="width:70%">
								<h1><a href="#">El Renzo Hotel</a></h1>
							</div>
						 
						<div class="profile_details w3l" style="width:29%">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										            <?php
													session_start();
													$name = $_SESSION["name"];
													$as = $_SESSION["as"];
													$user = $_SESSION["user"];
													include("php_connect.php");
													
													$sql = "SELECT * FROM staff WHERE Username='$user'";
													$res = mysqli_query($conn, $sql);
													$row = mysqli_fetch_array($res);
													?>
													
													
											<div class="profile_img">	
												<span class="prfil-img">
												<img src="<?php echo 'data:image/jpeg;base64,'.base64_encode( $row['ProfilePic'] ).''; ?>" alt=""/>
												</span> 
												<div class="user-name">
													<p><?php echo $name; ?></p>
													<span><?php echo $as; ?></span>
												</div>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<li> <a href="profile.php"><i class="fa fa-user"></i> Profile</a> </li> 
											<li> <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>
							
				     <div class="clearfix"> </div>	
				</div>