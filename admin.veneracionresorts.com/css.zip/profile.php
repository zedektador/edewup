<?php

include("weblock.php");
?><!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<?php
include("head.php");
?>
<body>
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
             <?php
				include("header.php");
			?>
				
		
<!--//four-grids here-->
<!--agileinfo-grap-->
<div class="inbox-mail">
	<div class="col-md-6 tab-content tab-content-in w3">
<div class="tab-pane text-style active" id="tab1">
  <div class="inbox-right">
         	
            <div class="mailbox-content">
                <div class="grid-form">
 		<div class="grid-form1">
 		        <?php
 		        include("php_connect.php");
 		        session_start();
 		        $user = $_SESSION["user"];
 		        $sql = "SELECT * FROM staff WHERE Username='$user'";
 		        $res = mysqli_query($conn, $sql);
 		        $row = mysqli_fetch_array($res);
 		        ?>
 		        
 		        <center>
 		            <div style="width:70%; height:225px;"><img src="<?php echo 'data:image/jpeg;base64,'.base64_encode( $row['ProfilePic'] ).''; ?>" alt="" style="max-height:225px; border: 1px solid black"/></div>
 		        </center>
 		    
 		    
                <h2 id="forms-example" class="">Change Password</h2>
			<form action="changepw.php" id="changepwForm" method="post">
	  
	   <div class="form-group">
		<label for="exampleInputPassword1">Old Password</label>
		<input type="password" name="opw" class="form-control" maxlength="30" required id="opw" >
	  </div>
	  
	  <div class="form-group">
		<label for="exampleInputPassword1">Password</label>
		<input type="password" name="pw" class="form-control" maxlength="30" required id="pw" >
	  </div>
	  
	  <div class="form-group">
		<label for="exampleInputPassword1">Confirm Password</label>
		<input type="password" class="form-control" name="cpw" required maxlength="30" id="cpw" >
	  </div>
	  
	  <div style="height:20px">
	  <button type="submit" style="float:right" onclick="return chk()" class="btn btn-success">Change Password</button>
	  </div>
	</form>
	</div>
    <script>
        function chk(){
            //check if they are the same
            var pw = $("#pw").val();
            var cpw = $("#cpw").val();
            var opw = $("#opw").val();
            
            if(pw == "" || cpw == "" || opw == ""){
                swal("Validation", "Please type a valid input.", "error");
                return false;
            }
            else if(pw != cpw){
                swal("Validation", "Passwords do not match.", "error");
                return false;
            }
            else{ //check if they match with the old password
                //ajax here to check pw
                  
                  $.ajax({
                    type:"post",
                    data:{
                        pw:opw,
                        npw: pw
                    },
                    url:"changepw.php",
                    success:function(data){
                        if(data == "not"){
                            swal("Validation", "Password does not match the old one.", "error");
                            return false;  
                        }
                        else{
                             swal("Success", "Password successfully changed.", "success");
                             $("#opw").val("");
                             $("#cpw").val("");
                             $("#pw").val("");
                        }
                    }
                  });
                  
                  return false;
            }
        }
    </script>

</div>
</div>
</div>
</div>
</div>
        
<div class="col-md-6 tab-content tab-content-in w3">
<div class="tab-pane text-style active" id="tab1">
  <div class="inbox-right">
    
    <?php
	if(isset($_GET["mess"])){
	?>
		<script>
			swal("Success", "Profile successfully updated.", "success");
			history.pushState(null, '', '/profile.php');
		</script>
	<?php
	}
	?>
	
         	
            <div class="mailbox-content">
                <div class="grid-form">
 		<div class="grid-form1">
                <h2 id="forms-example" class="">User Profile</h2>
			<form action="update_staff.php" method="post">
			    
	<?php
	//$row ung name nng variable
	$as = $_SESSION["as"];
	$name = $row["Name"];
	$number = $row["ContactNumber"];
	$email = $row["Email"];
	$address = $row["Address"];
	?>
			    
	  <div class="form-group">
		<label for="exampleInputEmail1">Username</label>
		<input type="" class="form-control" readonly id="exampleInputEmail1" value="<?php echo $user; ?>">
	  </div>
	  
	  
	  <div class="form-group">
		<label for="exampleInputEmail1">Position</label>
		<input type="" class="form-control" readonly id="exampleInputEmail1" value="<?php echo $as; ?>">
	  </div>
	  
	  <div class="form-group">
		<label for="exampleInputEmail1">Name</label>
		<input type="text" class="form-control" required maxlength="40" id="exampleInputEmail1" name="name" value="<?php echo $name; ?>">
	  </div>
	  
	  <div class="form-group">
		<label for="exampleInputEmail1">Contact Number</label>
		<input type="text" class="form-control" required maxlength="15"  id="exampleInputEmail1" name="number" value="<?php echo $number; ?>">
	  </div>
	  
	  <div class="form-group">
		<label for="exampleInputEmail1">Email address</label>
		<input type="email" class="form-control"  required maxlength="40" id="exampleInputEmail1" name="email" value="<?php echo $email; ?>">
	  </div>
	  
	  
	  <div class="form-group">
		<label for="exampleInputEmail1">Address</label>
		<input type="text" class="form-control"  required maxlength="40"  id="exampleInputEmail1" name="address" value="<?php echo $address; ?>">
	  </div>
	  
	  <div style="height:20px">
	  <button type="submit" name="submit" style="float:right" class="btn btn-success">Submit Changes</button>
	  </div>
	</form>
	</div>

</div>


</div>

</div>
</div>

</div>
</div>
	<!--//agileinfo-grap-->
<!--photoday-section-->	
			
                        
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block" style="clear:both; height:50px">

</div>
<!--inner block end here-->
<!--copy rights start here-->
<div class="copyrights">
	 <p>© 2018 El Renzo Hotel | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>	
<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
			<?php
			include("sidebar.php");
			?>
							  <div class="clearfix"></div>		
							</div>
			<?php
			include("js.php");
			?>
</body>
</html>