<!--/sidebar-menu-->
				<div class="sidebar-menu">
					<header class="logo1">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<ul id="menu" >
									   <?php
									   session_start();
									   $as = $_SESSION['as'];
									   if($as == "Admin"){
									   ?>
										<li><a href="index.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a></li>
										<li id="menu-academico" ><a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> Transactions</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   <ul id="menu-academico-sub" >
										   <li id="menu-academico-avaliacoes" ><a href="walk_checkin.php">Walk in Check-in</a></li>
										 	<li id="menu-academico-avaliacoes" ><a href="reservation.php">Walk-in Reservation</a></li>
										 	  <li id="menu-academico-avaliacoes" ><a href="reservation_list.php">Reservation List</a></li>
										</ul>
										</li>
										<li><a href="directory.php"><i class="fa fa-home"></i> <span>Guests' Directory</span><div class="clearfix"></div></a></li>
									
										<li id="menu-academico" ><a href="#"><i class="fa fa-key" aria-hidden="true"></i><span> Room Management</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   <ul id="menu-academico-sub" >
										  <li id="menu-academico-avaliacoes" ><a href="add_room.php">Add Room Type</a></li>
										   <li id="menu-academico-avaliacoes" ><a href="room_types.php">List of Room Types</a></li>
										 	<li id="menu-academico-avaliacoes" ><a href="maintenance.php">Room Maintenance</a></li>
										</ul>
										</li>
										<li id="menu-academico" ><a href="#"><i class="fa fa-user" aria-hidden="true"></i><span>Amenities/Rentals</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										<ul id="menu-academico-sub" >
										   <li id="menu-academico-avaliacoes" ><a href="amenities.php">Amenities</a></li>
										 	<li id="menu-academico-avaliacoes" ><a href="inventory.php">Rentals</a></li>
										</ul>
										</li>
										
										<li><a href="bankpayments.php"><i class="fa fa-credit-card"></i> <span>Proof of Payments</span><div class="clearfix"></div></a></li>
										
										<li><a href="messages.php"><i class="fa fa-file-o"></i> <span>Messages</span><div class="clearfix"></div></a></li>
										
										
										<li id="menu-academico" ><a href="reports.php"><i class="fa fa-book" aria-hidden="true"></i><span> Reports</span> </a>
										   
										</li>
										
										<li id="menu-academico" ><a href="#"><i class="fa fa-user" aria-hidden="true"></i><span> Accounts</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										<ul id="menu-academico-sub" >
										   <li id="menu-academico-avaliacoes" ><a href="staffs.php">Add Staff Accounts</a></li>
										 	<li id="menu-academico-avaliacoes" ><a href="staff_list.php">Staff Accounts</a></li>
										</ul>
										</li>
										<li id="menu-academico" ><a href="#"><i class="fa fa-gear" aria-hidden="true"></i><span> Settings</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   <ul id="menu-academico-sub" >
										   										   <li id="menu-academico-avaliacoes" ><a href="genset.php">General Settings</a></li>
										   										   <li id="menu-academico-avaliacoes" ><a href="about.php">About</a></li>
										   										   <li id="menu-academico-avaliacoes" ><a href="galle.php">Gallery</a></li>
										   										   
										   										   <li id="menu-academico-avaliacoes" ><a href="picCar.php">Picture Carousel</a></li>
										   										   <?php
									   }
									   else{
									   ?>
									   <li><a href="index.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a></li>
										<li id="menu-academico" ><a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> Transactions</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   <ul id="menu-academico-sub" >
										   <li id="menu-academico-avaliacoes" ><a href="walk_checkin.php">Walk in Check-in</a></li>
										 	<li id="menu-academico-avaliacoes" ><a href="reservation.php">Walk-in Reservation</a></li>
										 	  <li id="menu-academico-avaliacoes" ><a href="reservation_list.php">Reservation List</a></li>
										</ul>
										</li>
										<li><a href="directory.php"><i class="fa fa-home"></i> <span>Guests' Directory</span><div class="clearfix"></div></a></li>
									
										<li id="menu-academico" ><a href="#"><i class="fa fa-key" aria-hidden="true"></i><span> Room Management</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										   <ul id="menu-academico-sub" >
										 
										 	<li id="menu-academico-avaliacoes" ><a href="maintenance.php">Room Maintenance</a></li>
										</ul>
										</li>
										<li><a href="inventory.php"><i class="fa fa-th"></i> <span>Rentals</span><div class="clearfix"></div></a></li>
										<li><a href="bankpayments.php"><i class="fa fa-credit-card"></i> <span>Proof of Payments</span><div class="clearfix"></div></a></li>
										
										
									   <?php
									   }										   ?>
										  </ul>
										</li>
									</ul>
								</div>
							  </div>