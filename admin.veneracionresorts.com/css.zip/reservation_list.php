<?php

include("weblock.php");
?><!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<?php
include("head.php");
?>
<body onload="updDate()">
   <div class="page-container">
   <!--/content-inner-->
<div class="left-content">
	   <div class="mother-grid-inner">
             <?php
				include("header.php");
			?>
		
<!--agileinfo-grap-->
<div class="agileinfo-grap">
    <?php
    include("con_reservationList.php");
    ?>
</div>
	<!--//agileinfo-grap-->
<!--photoday-section-->	
			
                        
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block" style="clear:both; height:5px">

</div>
<!--inner block end here-->
<!--copy rights start here-->
<div class="copyrights">
	 <p>© 2018 El Renzo Hotel | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>	
<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
			<?php
			include("sidebar.php");
			?>
							  <div class="clearfix"></div>		
							</div>
			<?php
			include("js.php");
			?>
</body>
</html>

<script>

$("#print").click(function () {
	window.location.href="<?php 
	if(isset($_GET["view"])){
		echo "print_resSlip.php?reprint=".$_GET["view"]; 
	}
	else{
		echo "print_resSlip.php";
	}
	?>";
});

$("#print_").click(function () {
	window.location.href="<?php 
	if(isset($_GET["rm2"])){
		echo "print_resSlip.php?save=".$_GET["rm2"]; 
	}
	else{
		echo "print_resSlip.php";
	}
	?>";
});


$("#next").click(function(){			
	//check if there is a room selected.
	//check if it does not exceed max room.
	var sum = 0;
	var mess = "";
	var submess = "";
	
	var sumcap = 0;
	var guest = <?php
		echo $_SESSION["ed_guest"];
	?>;
	
	$('.quan').each(function(){
         sum += parseInt($(this).val());
    });
	
	$('.totalcap').each(function(){
         if ($(this).val() != "") {
			sumcap += parseInt($(this).val());
		}
	});
	
	
	if(sum == 0){
		mess = "No room selected yet!";
		submess = "There must be atleast 1 room selected";
		swal(mess, submess, "warning");
	}
	/*
	else if(sumcap < guest){
		mess = "The rooms cannot accommodate number of guest.";
		submess = "Check room capacity."
		swal(mess, submess, "warning");
	}
	*/
	else{
		
			var numperroom = "";
			$(".forsess").each(function() {
				numperroom += $(this).val() + ";";
			});
			
		//for sessions
		$.ajax({
			url: "session_checkin_edit.php",
			method: "post",
			data: {
				numperroom_post : numperroom
			},
			success: function(){
				window.location.href="<?php 
				if(isset($_GET["rm"])){
					echo "reservation_list.php?rm2=".$_GET["rm"];
				}
				else{	
					echo "reservation_list.php";
				}
				 ?>";
			}
		});
		
	}
});


</script>